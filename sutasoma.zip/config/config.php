<?php
$base_url = 'http://localhost/sutasoma/'; //URL utama website