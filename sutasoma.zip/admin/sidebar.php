	<ul class="nav nav-side-menu">
		<li><a href="beranda.php"><i class="fa fa-home"></i> Beranda</a></li>
		<li><a href="berita.php"><i class="fa fa-newspaper-o"></i> Berita</a></li>
		<li><a href="kategori.php"><i class="fa fa-folder-o"></i> Kategori</a></li>
		<li><a href="profil.php"><i class="fa fa-user"></i> Profil</a></li>
		<li><a href="buku-tamu.php"><i class="fa fa-book"></i> Buku Tamu</a></li>
		<li><a href="pesan.php"><i class="fa fa-envelope"></i> Pesan</a></li>
		<li><a href="#" data-toggle="modal" data-target="#modal_logout">Logout <i class="fa fa-sign-out"></i></a></li>
	</ul>
