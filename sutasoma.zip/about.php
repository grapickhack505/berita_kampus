<?php include 'header.php'; ?>
<div class="container-fluid">
	<div class="row">
		<div class="container konten-wrapper">
			<div class="panel panel-default">
				<div class="panel-body main">
					<div class="col-md-8">
						<div class="about">
							<div class="row post-title">
								<div class="col-sm-12">
									<h2>TENTANG BERITA KITA</h2>
								</div>
							</div>
							<div class="row post-content">
								<div class="col-sm-12">
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facere ex tenetur iste dolores unde cupiditate veritatis perspiciatis quidem vel ducimus accusamus quo, aut, deleniti architecto accusantium, delectus, cumque dolorum quasi ad ipsum eveniet error. Optio dolorem cupiditate, quo aperiam recusandae quis, praesentium laudantium in suscipit alias tempore necessitatibus expedita tempora sequi minima laborum nesciunt dolores ratione, sed, molestiae iste doloribus voluptatibus voluptates. Omnis perferendis maxime voluptatibus ipsum minus eius nesciunt harum nihil consequatur, incidunt 	eos.</p>
									<p>In delectus tempore a et amet, ea facere pariatur unde sit! Fugit culpa unde omnis cupiditate, aliquam inventore incidunt quos vero soluta eligendi non similique voluptates officiis nesciunt et maiores pariatur repellendus, dolorem recusandae provident tenetur! Excepturi maiores autem ad! Inventore animi rem, deleniti libero, cupiditate quae commodi enim, quasi a mollitia accusantium dolorem reiciendis, magni sed ad. Placeat ex maiores, voluptatibus facere quas sunt 	animi, non adipisci numquam alias nihil nisi quod accusamus ratione.</p>
									<p>Voluptates exercitationem amet dolore incidunt rerum est nobis, aperiam similique, laborum, quos molestias nihil vel unde esse ex illum sint sapiente corporis odit repudiandae quasi? Doloremque et temporibus, saepe nulla necessitatibus cum itaque eius voluptatem vitae molestiae eaque quia, officia placeat aperiam voluptate quo rem molestias ea, facere, aliquam explicabo magnam! Quidem vero excepturi distinctio repudiandae quod delectus, harum ex molestiae in ratione sunt, itaque 	odio quo eum ducimus? Enim aut reiciendis repellat consequuntur sequi?</p>
								</div>
							</div>
						</div>
					</div>
					<?php include 'sidebar.php'; ?>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'footer.php';